sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("sync.ea.salesai.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  