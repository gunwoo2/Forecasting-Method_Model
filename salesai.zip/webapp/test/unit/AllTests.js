sap.ui.define([
	"syncea/salesai/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
